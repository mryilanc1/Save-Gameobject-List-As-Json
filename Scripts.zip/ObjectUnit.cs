using System.Collections.Generic;
using UnityEngine;

namespace Editor
{
    [System.Serializable]
    public class ObjectUnit
    {
        public string ObjectName;
        public int ObjectID;
        public string ColliderName;
        public string LayerName;
        public List<MaterialUnit> Materials = new List<MaterialUnit>();

        public ObjectUnit (string objectName, int objectID, string colliderName, string layerName, Transform tr)
        {
            ObjectName = objectName;
            ObjectID = objectID;
            ColliderName = colliderName;
            LayerName = layerName;

            if (!tr.TryGetComponent(out MeshRenderer renderer)) return;
            foreach (var mat in renderer.sharedMaterials)
            {
                var materialUnit = new MaterialUnit(mat.name, mat.GetInstanceID());
                Materials.Add(materialUnit);
            }
        }
    }
}
