using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace Editor
{
    public class SaveObjectData : EditorWindow
    {
        public ListObject Root = new ListObject();
        private SerializedObject m_SerializedObject;
        private Vector2 m_Scroll = Vector2.zero;
        private static Transform[] AllObject;
        private string m_SaveName;
        private ScriptableMaterial m_MaterialPool;
        private GameObject m_ParentRef;

        [MenuItem("Tool/Object_Save_Editor")]
        public static void ShowWindow ()
        {
            SaveObjectData window = (SaveObjectData) GetWindow(typeof (SaveObjectData), false, "Save Object Data Editor");
            window.Show();
        }

        void OnGUI ()
        {
            EditorGUILayout.BeginVertical();

            m_ParentRef = EditorGUILayout.ObjectField("Parent Object", m_ParentRef, typeof (GameObject)) as GameObject;
            if (m_ParentRef != null)
                AllObject = m_ParentRef.GetComponentsInChildren<Transform>();

            if (GUILayout.Button("Read All Objects", GUILayout.Height(50), GUILayout.MinWidth(160)))
            {
                ReadAllObjects();
            }

            m_SaveName = EditorGUILayout.TextField("Save Name:", m_SaveName);
            if (GUILayout.Button("Save to Json", GUILayout.Height(50), GUILayout.MinWidth(160)))
            {
                string jsonAdded = JsonUtility.ToJson(Root);
                File.WriteAllText(Application.dataPath + "/" + m_SaveName + ".json", jsonAdded);
                AssetDatabase.Refresh();
            }

            if (GUILayout.Button("Load Json", GUILayout.Height(50), GUILayout.MinWidth(160)))
            {
                TextAsset jsonYazi =
                    new TextAsset(File.ReadAllText(Application.dataPath + "/" + m_SaveName + ".json"));

                Root.ObjectList.Clear();
                Root = JsonUtility.FromJson<ListObject>(jsonYazi.text);
            }

            if (GUILayout.Button("Parse Colliders", GUILayout.Height(50), GUILayout.MinWidth(160)))
            {
                ParseAllObjects();
            }

            m_MaterialPool =
                (ScriptableMaterial) EditorGUILayout.ObjectField("Materyaller", m_MaterialPool,
                    typeof (ScriptableMaterial));

            EditorGUILayout.EndVertical();

            m_Scroll = EditorGUILayout.BeginScrollView(m_Scroll);

            EditorGUILayout.BeginVertical();

            ScriptableObject target = this;
            m_SerializedObject = new SerializedObject(target);
            SerializedProperty stringsProperty = m_SerializedObject.FindProperty("Root");
            EditorGUILayout.PropertyField(stringsProperty, true); // True means show children
            m_SerializedObject.ApplyModifiedProperties();

            EditorGUILayout.EndVertical();
            EditorGUILayout.EndScrollView();
        }

        private void ReadAllObjects ()
        {
            Root.ObjectList.Clear();
            foreach (var tr in AllObject)
            {
                if (!tr.TryGetComponent(out Collider col)) continue;
                var obj = new ObjectUnit(tr.name, tr.GetInstanceID(), col.GetColName(), LayerMask.LayerToName(tr.gameObject.layer), tr);

                Root.ObjectList.Add(obj);
            }

            EditorUtility.ClearProgressBar();
        }

        private void ParseAllObjects ()
        {
            foreach (var transform in AllObject)
            {
                var objectUnit = Root.ObjectList.FirstOrDefault(x => x.ObjectID == transform.GetInstanceID());
                if (objectUnit == null) continue;

                objectUnit.ColliderName.GetColliderFromName(out var x);
                if (!transform.TryGetComponent(typeof (Collider), out _))
                    transform.gameObject.AddComponent(x.GetType());

                if (!transform.TryGetComponent(out MeshRenderer renderer)) continue;

                bool isOk = false;
                var list = new List<Material>();
                foreach (var item in objectUnit.Materials)
                {
                    var mat = m_MaterialPool.Materials.FirstOrDefault(x => x.GetInstanceID().Equals(item.MaterialID));
                    isOk = mat != null;
                    if (isOk) list.Add(mat);
                }

                if (isOk) renderer.sharedMaterials = list.ToArray();
            }

            Array.Clear(AllObject, 0, AllObject.Length);
        }
    }
}