﻿using UnityEngine;

namespace Editor
{
    public static class ExternalExtensions
    {
        public static string GetColName (this Collider collider)
        {
            if (collider is MeshCollider)
                return "MeshCollider";
            if (collider is BoxCollider)
                return "BoxCollider";
            if (collider is CapsuleCollider)
                return "CapsuleCollider";
            if (collider is SphereCollider)
                return "SphereCollider";
            if (collider is TerrainCollider)
                return "TerrainCollider";
            if (collider is WheelCollider)
                return "WheelCollider";
            return null;
        }

        public static void GetColliderFromName (this string name, out Collider output)
        {
            if (name.Contains("Box"))
            {
                output = new BoxCollider();
            }
            else if (name.Contains("Mesh"))
            {
                output = new MeshCollider();
            }
            else if (name.Contains("Terrain"))
            {
                output = new TerrainCollider();
            }
            else if (name.Contains("Capsule"))
            {
                output = new CapsuleCollider();
            }
            else if (name.Contains("Sphere"))
            {
                output = new SphereCollider();
            }
            else if (name.Contains("Wheel"))
            {
                output = new WheelCollider();
            }
            else
            {
                output = null;
            }
        }
    }
}